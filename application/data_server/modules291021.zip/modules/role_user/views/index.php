<div class="page-title-box">
  <div class="row align-items-center">
    <div class="col-sm-6"><h4 class="page-title"><?= $title ?></h4></div>
    <div class="col-sm-6">
      <?php echo bredcumx(); ?>
    </div>
  </div>
</div>

<?php if ($role['read'] == true || $role == null): ?>
  <div class="row">
    <div class="col-md-7">
      <div class="card shadow">
        <div class="card-body">
          <table id="datatable" class="table table-bordered table-hover dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
            <thead class="thead-light text-center">
              <tr>
                <th>No</th>
                <th>Level Otorisasi</th>
                <th>Jabatan</th>
                <th>Aksi</th>
              </tr>
            </thead>
          </table>
        </div>
      </div>
    </div>
    <div class="col-md-5">
      <div class="card shadow">
        <div class="card-header">
          <h5 class="mb-0 judul">Tambah Data</h5>
        </div>
        <div class="card-body">
          <div class="form-group">
            <label>Otorisasi<b style="color:red;">*</b></label>
            <input type="hidden" name="idrol" id="idrol" value="">
            <select name="idoto" id="idoto" class="form-control select2" required>
              <option value="">-- Pilih --</option>
              <?php foreach ($otorisa as $key) { ?>
                <option value="<?php echo $key->id_level_otorisasi; ?>"><?php echo $key->level_otorisasi; ?></option>
              <?php } ?>
            </select>
          </div>
          <div class="form-group">
            <label>Jabatan<b style="color:red;">*</b></label>
            <select name="idjab" id="idjab" class="form-control select2" required>
              <option value="">-- Pilih --</option>
              <?php foreach ($jabatan as $key) { ?>
                <option value="<?php echo $key->id_jabatan; ?>"><?php echo $key->jabatan; ?></option>
              <?php } ?>
            </select>
          </div>
          <i style="color:red;">('*') Menandakan Form Harus di Isi</i>
        </div>
        <div class="card-footer d-flex justify-content-end">
          <?php if ($role['create'] == true || $role == null): ?>
            <button class="btn btn-primary waves-effect waves-light mr-2" id="senddata">Simpan</button>
          <?php endif; ?>
          <button class="btn btn-secondary waves-effect m-l-5" id="clearall">Batal</button>
        </div>
      </div>
    </div>
  </div>
<?php endif; ?>

<script type="text/javascript">
  var tabel_role = '';
  $(document).ready(function () {
    var act = "<?=$role['update'].'_'.$role['delete']?>";
    tabel_role = $('#datatable').DataTable({
      "processing" : true,
      "serverSide" : true,
      "order" : [],
      "ajax" : {
        "url" : "<?php echo base_url(); ?>role_user/ajaxdata/"+act,
        "type" : "POST"
      },
      "columnDefs" : [{
        "targets" : [0,3],
        "orderable" : false
      },{
        'targets' : [0,3],
        'className' : 'text-center',
      }],
      "scrollX" : true
    });

    $('#clearall').on('click', function () {
      $('#idrol').val('');
      $('#idjab').val(null).trigger('change');
      $('#idoto').val(null).trigger('change');

      $('.judul').text('Tambah Data');
    });

    $('#senddata').on('click', function () {
      var idjb = $('#idjab').val();
      var idot = $('#idoto').val();
      var idrl = $('#idrol').val();
      if (idrl == "") { //insert
        $.ajax({
          type:"POST",
          url:"<?php echo base_url(); ?>role_user/add",
          beforeSend : function () {
            swal({
              title  : 'Menunggu',
              html   : 'Memproses Data',
              onOpen : () => {
                swal.showLoading();
              }
            })
          },
          data: { lvlot:idot, idjbt:idjb },
          dataType : "JSON",
          success  : function (data) {
            swal({
              title             : data['status'],
              text              : data['pesan'],
              type              : data['altr'],
              showConfirmButton : false,
              timer             : 1000
            });
            if (data['altr'] == 'success') {
              $('#clearall').trigger('click');
            }
            tabel_role.ajax.reload();
            return true;
          },
          error: function (jqXHR, textStatus, errorThrown) {
            swal({
              title             : "Peringatan",
              text              : "Koneksi Tidak Terhubung",
              type              : 'warning',
              showConfirmButton : false,
              timer             : 1000
            });
            return false;
          }
        });
      } else { //update
        $.ajax({
          type:"POST",
          url:"<?php echo base_url(); ?>role_user/edit/"+idrl,
          beforeSend : function () {
            swal({
              title  : 'Menunggu',
              html   : 'Memproses Data',
              onOpen : () => {
                swal.showLoading();
              }
            })
          },
          data: { lvlot:idot, idjbt:idjb },
          dataType : "JSON",
          success  : function (data) {
            swal({
              title             : data['status'],
              text              : data['pesan'],
              type              : data['altr'],
              showConfirmButton : false,
              timer             : 1000
            });
            if (data['altr'] == 'success') {
              $('#clearall').trigger('click');
            }
            tabel_role.ajax.reload();
            return true;
          },
          error: function (jqXHR, textStatus, errorThrown) {
            swal({
              title             : "Peringatan",
              text              : "Koneksi Tidak Terhubung",
              type              : 'warning',
              showConfirmButton : false,
              timer             : 1000
            });
            return false;
          }
        });
      }
    });
  });

  function ubahubah(id) {
    window.scrollTo(0,0);
    $.ajax({
      type:"GET",
      url:"<?php echo base_url(); ?>role_user/show/"+id,
      success  : function (data) {
        var hss = JSON.parse(data);
        $('#idjab').val(hss[0].id_jabatan).trigger('change');
        $('#idoto').val(hss[0].id_level_otorisasi).trigger('change');
        $('#idrol').val(hss[0].id_role);

        $('.judul').text('Ubah Data');
      },
      error: function (jqXHR, textStatus, errorThrown) {
        swal({
          title             : "Peringatan",
          text              : "Koneksi Tidak Terhubung",
          type              : 'warning',
          showConfirmButton : false,
          timer             : 1000
        });
        return false;
      }
    });
  }

  function deletedel(id) {
    swal({
      title       : 'Konfirmasi',
      text        : 'Yakin akan menghapus data ini?',
      type        : 'warning',
      buttonsStyling      : false,
      confirmButtonClass  : "btn btn-danger",
      cancelButtonClass   : "btn btn-primary mr-3",
      showCancelButton    : true,
      confirmButtonText   : 'Ya',
      confirmButtonColor  : '#3085d6',
      cancelButtonColor   : '#d33',
      cancelButtonText    : 'Batal',
      reverseButtons      : true
    }).then((result) => {
      if (result.value) {
        $.ajax({
          type:"GET",
          url:"<?php echo base_url(); ?>role_user/remove/"+id,
          beforeSend : function () {
            swal({
              title  : 'Menunggu',
              html   : 'Memproses Data',
              onOpen : () => {
                swal.showLoading();
              }
            })
          },
          success  : function (data) {
            swal({
              title             : "Berhasil",
              text              : "Role telah di Hapus",
              type              : 'success',
              showConfirmButton : false,
              timer             : 1000
            });
            $('.judul').text('Tambah Data');
            tabel_role.ajax.reload();
            return true;
          },
          error: function (jqXHR, textStatus, errorThrown) {
            swal({
              title             : "Peringatan",
              text              : "Koneksi Tidak Terhubung",
              type              : 'warning',
              showConfirmButton : false,
              timer             : 1000
            });
            return false;
          }
        });
      } else if (result.dismiss === swal.DismissReason.cancel) {
        // swal({
        //   title               : "Batal",
        //   text                : 'Anda membatalkan Hapus Role',
        //   buttonsStyling      : false,
        //   confirmButtonClass  : "btn btn-primary",
        //   type                : 'error',
        //   showConfirmButton   : false,
        //   timer               : 1000
        // });
      }
    });
  }
</script>
