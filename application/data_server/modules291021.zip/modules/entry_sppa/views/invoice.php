<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Invoice</title>
    <style>
        p {
            line-height: 1.8;
        }
    </style>
</head>
<body>
 
<div id="container">
    <img src="<?= base_url('assets/img/legowo icon.png') ?>" style="width: 30%; float: lleft; margin-top: -20px;">
    

    <table cellspacing="3" style="margin-left: 400px;">
        <tr>
            <td>For and on behalf of</td>
        </tr>
        <tr>
            <td> PT. Legowo Insurance Broker</td>
        </tr>
        <tr>
            <td></td>
        </tr>
        <tr>
            <td></td>
        </tr>
        <tr>
            <td></td>
        </tr>
        <tr>
            <td></td>
        </tr>
        <tr>
            <td></td>
        </tr>
        </tr>
        <tr>
            <td></td>
        </tr>
        <tr>
            <td></td>
        </tr>
        <tr>
            <td><hr><br> Authorized Signature</td>
        </tr>
    </table>
    <br><br><br>

    <strong><u><i>PLEASE TRANSFERRED PREMIUM TO ACCOUNT NO </i></u></strong>
    <br>
    <br>
    <strong><i>PT LEGOWO <br>
    BANK BRI  CAB PONDOK INDAH (IDR) <br>
    NO. REK   036201001493309</i></strong>


</div>
 
</body>
</html>